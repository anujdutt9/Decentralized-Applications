Please copy the code in the .sol file and paste it into the Remix editor.
